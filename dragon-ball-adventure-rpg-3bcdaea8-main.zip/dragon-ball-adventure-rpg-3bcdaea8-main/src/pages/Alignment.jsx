import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Heart, Skull, Scale, Sparkles, Award } from "lucide-react";
import { motion } from "framer-motion";

const alignmentData = {
  "-8": { label: "Chaotic Evil", color: "from-purple-900 to-black", textColor: "text-purple-300", icon: Skull },
  "-7": { label: "Chaotic Evil", color: "from-purple-800 to-purple-950", textColor: "text-purple-200", icon: Skull },
  "-6": { label: "Evil", color: "from-red-900 to-purple-900", textColor: "text-red-300", icon: Skull },
  "-5": { label: "Evil", color: "from-red-800 to-red-950", textColor: "text-red-200", icon: Skull },
  "-4": { label: "Evil", color: "from-red-700 to-red-900", textColor: "text-red-200", icon: Skull },
  "-3": { label: "Evil", color: "from-red-600 to-red-800", textColor: "text-red-100", icon: Skull },
  "-2": { label: "Neutral", color: "from-gray-700 to-gray-900", textColor: "text-gray-300", icon: Scale },
  "-1": { label: "Neutral", color: "from-gray-600 to-gray-800", textColor: "text-gray-200", icon: Scale },
  "0": { label: "Neutral", color: "from-gray-500 to-gray-700", textColor: "text-gray-100", icon: Scale },
  "1": { label: "Neutral", color: "from-gray-600 to-gray-800", textColor: "text-gray-200", icon: Scale },
  "2": { label: "Neutral", color: "from-gray-700 to-gray-900", textColor: "text-gray-300", icon: Scale },
  "3": { label: "Good", color: "from-blue-600 to-blue-800", textColor: "text-blue-100", icon: Heart },
  "4": { label: "Good", color: "from-blue-700 to-blue-900", textColor: "text-blue-200", icon: Heart },
  "5": { label: "Good", color: "from-blue-800 to-blue-950", textColor: "text-blue-300", icon: Heart },
  "6": { label: "Good", color: "from-cyan-700 to-blue-900", textColor: "text-cyan-200", icon: Heart },
  "7": { label: "Lawful Good", color: "from-cyan-600 to-cyan-800", textColor: "text-cyan-100", icon: Heart },
  "8": { label: "Lawful Good", color: "from-yellow-400 to-cyan-600", textColor: "text-yellow-100", icon: Award },
};

export default function AlignmentPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to view alignment</p>
        </Card>
      </div>
    );
  }

  const alignmentValue = Math.min(8, Math.max(-8, character.alignment || 0));
  const alignmentInfo = alignmentData[alignmentValue.toString()];
  const AlignmentIcon = alignmentInfo.icon;
  const progress = ((alignmentValue + 8) / 16) * 100;

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-black text-white mb-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
            Alignment System
          </h1>
          <p className="text-gray-300 text-lg">Your moral path shapes your destiny</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className={`bg-gradient-to-br ${alignmentInfo.color} border-4 border-white/20 shadow-2xl`}>
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-xl">
                    <AlignmentIcon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-3xl font-black text-white">
                      {alignmentInfo.label}
                    </CardTitle>
                    <p className={`text-xl font-bold ${alignmentInfo.textColor}`}>
                      Level: {alignmentValue}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-white font-semibold">Alignment Progress</span>
                      <span className="text-white font-bold">{alignmentValue}/8</span>
                    </div>
                    <Progress 
                      value={progress} 
                      className="h-4 bg-black/30 border-2 border-white/20" 
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-6">
                    <div className="text-center p-3 bg-black/20 rounded-lg border border-white/10">
                      <div className="text-red-400 text-2xl font-black">-8</div>
                      <div className="text-xs text-white/70">Chaotic</div>
                    </div>
                    <div className="text-center p-3 bg-black/20 rounded-lg border border-white/10">
                      <div className="text-gray-400 text-2xl font-black">0</div>
                      <div className="text-xs text-white/70">Neutral</div>
                    </div>
                    <div className="text-center p-3 bg-black/20 rounded-lg border border-white/10">
                      <div className="text-cyan-400 text-2xl font-black">+8</div>
                      <div className="text-xs text-white/70">Lawful</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-4"
          >
            <Card className="bg-gradient-to-br from-green-900/30 to-emerald-950/50 border-2 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Heart className="w-5 h-5 text-green-400" />
                  Good Benefits
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-200 space-y-2 text-sm">
                <p>• Access to Good-only techniques (Kamehameha, Heal, Spirit Bomb)</p>
                <p>• +3% Charisma at +3 alignment or above</p>
                <p>• +2 bonus Strength per week from teaching jobs</p>
                <p>• 50% reduced damage from Spirit Bomb</p>
                <p>• Special good-aligned quests and items</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-900/30 to-purple-950/50 border-2 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Skull className="w-5 h-5 text-red-400" />
                  Evil Benefits
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-200 space-y-2 text-sm">
                <p>• Access to Evil-only techniques (Darkness attacks)</p>
                <p>• +3% Damage at -3 alignment or below</p>
                <p>• 50% reduced damage from Darkness attacks</p>
                <p>• Special evil-aligned quests and items</p>
                <p>• Ability to steal Dragonballs more effectively</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-2 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white text-2xl font-bold">How to Change Alignment</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-900/20 rounded-lg border border-green-500/30">
                  <h3 className="text-green-400 font-bold mb-2 flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    Increase (Good Actions)
                  </h3>
                  <ul className="space-y-1 text-sm">
                    <li>• Spare opponents in battle</li>
                    <li>• Complete good-aligned quests</li>
                    <li>• Help other players</li>
                    <li>• Protect the innocent</li>
                  </ul>
                </div>
                
                <div className="p-4 bg-red-900/20 rounded-lg border border-red-500/30">
                  <h3 className="text-red-400 font-bold mb-2 flex items-center gap-2">
                    <Skull className="w-4 h-4" />
                    Decrease (Evil Actions)
                  </h3>
                  <ul className="space-y-1 text-sm">
                    <li>• Kill defeated opponents</li>
                    <li>• Complete evil-aligned quests</li>
                    <li>• Steal from others</li>
                    <li>• Cause destruction</li>
                  </ul>
                </div>
              </div>

              <div className="mt-6 p-4 bg-yellow-900/20 rounded-lg border-2 border-yellow-500/50">
                <p className="text-yellow-200 font-semibold">
                  ⚠️ Important: Once you reach Lawful Good (+7), you can never become Chaotic Evil (-7) and vice versa. 
                  You'll always maintain the "Lawful" or "Chaotic" prefix.
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}