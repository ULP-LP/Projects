import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Zap, Star, Target, Shield as ShieldIcon, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const techniquesData = {
  fundamental: [
    { name: "Energy Blast", dr: 2, ki: 3, actions: "1", sp: 3, description: "Basic energy attack. Can be used every post." },
    { name: "Power Up", dr: 0, ki: 0, actions: "1", sp: 4, description: "Increase power temporarily. +10% all stats for 3 turns." },
    { name: "Dodge", dr: 0, ki: 2, actions: "1", sp: 3, description: "Attempt to evade incoming attack." },
  ],
  advanced: [
    { name: "Kamehameha", dr: 6, ki: 10, actions: "1-3", sp: 19, master: "Master Roshi", description: "Iconic energy wave. Powerful beam attack." },
    { name: "Special Beam Cannon", dr: 8, ki: 15, actions: "2", sp: 21, master: "Kami", description: "Piercing beam with high damage." },
    { name: "Final Flash", dr: 9, ki: 20, actions: "2-4", sp: 25, description: "Devastating energy wave attack." },
  ],
  finisher: [
    { name: "Spirit Bomb", dr: 12, ki: 30, actions: "3-5", sp: 26, master: "King Kai", description: "Ultimate energy sphere. Extremely powerful." },
    { name: "Destructo Disk", dr: 10, ki: 25, actions: "2", sp: 19, description: "Energy disk that can cut through almost anything." },
  ],
  stances: [
    { name: "Wolf Stance", dr: 0, ki: 5, actions: "1", sp: 11, master: "Master Roshi", description: "+15% Speed, +10% Strength while active" },
    { name: "Crane Stance", dr: 0, ki: 5, actions: "1", sp: 11, description: "+15% Intelligence, +10% Defense while active" },
  ],
};

export default function TechniquesPage() {
  const [user, setUser] = useState(null);
  const [selectedTab, setSelectedTab] = useState("fundamental");
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const learnTechnique = (technique) => {
    if (!character || character.sp < technique.sp) return;
    if (character.techniques.includes(technique.name)) return;

    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        sp: character.sp - technique.sp,
        techniques: [...character.techniques, technique.name],
      },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to learn techniques</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Techniques</h1>
          <p className="text-gray-400">Learn powerful techniques to dominate in battle</p>
          <div className="mt-4 flex gap-4">
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/50 text-lg px-4 py-2">
              SP: {character.sp}
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50 text-lg px-4 py-2">
              Techniques Learned: {character.techniques.length}
            </Badge>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-900 border border-orange-900/30 mb-6">
            <TabsTrigger value="fundamental" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Zap className="w-4 h-4 mr-2" />
              Basic
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Star className="w-4 h-4 mr-2" />
              Advanced
            </TabsTrigger>
            <TabsTrigger value="finisher" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Target className="w-4 h-4 mr-2" />
              Finishers
            </TabsTrigger>
            <TabsTrigger value="stances" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <ShieldIcon className="w-4 h-4 mr-2" />
              Stances
            </TabsTrigger>
          </TabsList>

          {Object.keys(techniquesData).map((category) => (
            <TabsContent key={category} value={category} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {techniquesData[category].map((tech, index) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300">
                      <CardHeader>
                        <div className="flex items-center justify-between mb-2">
                          <CardTitle className="text-white">{tech.name}</CardTitle>
                          {character.techniques.includes(tech.name) && (
                            <Badge className="bg-green-500/20 text-green-300 border-green-500/50">
                              Learned
                            </Badge>
                          )}
                        </div>
                        <CardDescription className="text-gray-400">
                          {tech.description}
                        </CardDescription>
                        {tech.master && (
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50 w-fit mt-2">
                            Master: {tech.master}
                          </Badge>
                        )}
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                          {tech.dr > 0 && (
                            <div className="p-2 bg-red-900/20 rounded border border-red-500/30">
                              <div className="text-xs text-gray-400">Damage</div>
                              <div className="text-red-400 font-bold">DR {tech.dr}</div>
                            </div>
                          )}
                          <div className="p-2 bg-blue-900/20 rounded border border-blue-500/30">
                            <div className="text-xs text-gray-400">Ki Cost</div>
                            <div className="text-blue-400 font-bold">{tech.ki}%</div>
                          </div>
                          <div className="p-2 bg-gray-800 rounded">
                            <div className="text-xs text-gray-400">Actions</div>
                            <div className="text-gray-300 font-bold">{tech.actions}</div>
                          </div>
                          <div className="p-2 bg-purple-900/20 rounded border border-purple-500/30">
                            <div className="text-xs text-gray-400">SP Cost</div>
                            <div className="text-purple-400 font-bold">{tech.sp} SP</div>
                          </div>
                        </div>

                        <Button
                          onClick={() => learnTechnique(tech)}
                          disabled={
                            character.sp < tech.sp ||
                            character.techniques.includes(tech.name) ||
                            updateCharacterMutation.isPending
                          }
                          className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
                        >
                          {character.techniques.includes(tech.name)
                            ? "Already Learned"
                            : character.sp < tech.sp
                            ? `Need ${tech.sp} SP`
                            : "Learn Technique"}
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 mt-8">
          <CardHeader>
            <CardTitle className="text-white">How to Earn SP</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-400 space-y-2">
            <p>• Complete battles and quests</p>
            <p>• Train with masters for stat bonuses and SP rewards</p>
            <p>• Level up your character</p>
            <p>• Advanced techniques require specific masters to unlock</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}