import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Scroll, Trophy, CheckCircle, Clock, Coins, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const availableQuests = [
  {
    title: "Defeat the Bandits",
    description: "A group of bandits has been terrorizing a nearby village. Defeat them and restore peace.",
    difficulty: "Easy",
    reward_zeni: 300,
    reward_exp: 250,
    required_level: 1,
  },
  {
    title: "Retrieve the Ancient Artifact",
    description: "An ancient artifact has been stolen. Track down the thieves and recover it.",
    difficulty: "Medium",
    reward_zeni: 600,
    reward_exp: 500,
    reward_item: "Ancient Amulet",
    required_level: 3,
  },
  {
    title: "Challenge the Tournament Champion",
    description: "Enter the martial arts tournament and defeat the reigning champion.",
    difficulty: "Hard",
    reward_zeni: 1200,
    reward_exp: 1000,
    reward_item: "Champion's Belt",
    required_level: 5,
  },
  {
    title: "Defend Against the Invasion",
    description: "An alien force is attacking Earth. Join the defense and repel the invaders.",
    difficulty: "Extreme",
    reward_zeni: 2500,
    reward_exp: 2000,
    reward_item: "Legendary Gear",
    required_level: 10,
  },
];

export default function QuestsPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const { data: quests, isLoading } = useQuery({
    queryKey: ['quests'],
    queryFn: () => base44.entities.Quest.list(),
    initialData: [],
  });

  const character = characters[0];

  const createQuestMutation = useMutation({
    mutationFn: (questData) => base44.entities.Quest.create(questData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['quests'] });
    },
  });

  const updateQuestMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Quest.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['quests'] });
    },
  });

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const acceptQuest = (quest) => {
    if (!character) return;
    
    createQuestMutation.mutate({
      ...quest,
      status: "active",
      character_id: character.id,
    });
  };

  const completeQuest = (quest) => {
    if (!character) return;

    // Update character with rewards
    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        zeni: character.zeni + quest.reward_zeni,
        experience: character.experience + quest.reward_exp,
      },
    });

    // Mark quest as completed
    updateQuestMutation.mutate({
      id: quest.id,
      data: { status: "completed" },
    });
  };

  const activeQuests = quests.filter((q) => q.status === "active" && q.character_id === character?.id);
  const completedQuests = quests.filter((q) => q.status === "completed" && q.character_id === character?.id);

  const difficultyColors = {
    Easy: "from-green-500 to-emerald-500",
    Medium: "from-yellow-500 to-orange-500",
    Hard: "from-red-500 to-pink-500",
    Extreme: "from-purple-500 to-indigo-500",
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to accept quests</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Quest Board</h1>
          <p className="text-gray-400">
            Accept quests to earn rewards and gain experience
          </p>
        </div>

        {activeQuests.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Clock className="w-6 h-6 text-orange-400" />
              Active Quests
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {activeQuests.map((quest) => (
                <motion.div
                  key={quest.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="bg-gradient-to-br from-orange-900/20 to-yellow-900/20 border-orange-500/50">
                    <CardHeader>
                      <CardTitle className="text-white">{quest.title}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {quest.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button
                        onClick={() => completeQuest(quest)}
                        className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Complete Quest
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Scroll className="w-6 h-6 text-blue-400" />
            Available Quests
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {availableQuests.map((quest, index) => (
              <motion.div
                key={quest.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300 h-full">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={`bg-gradient-to-r ${difficultyColors[quest.difficulty]} text-white border-0`}>
                        {quest.difficulty}
                      </Badge>
                      <Badge className="bg-gray-800 text-gray-300">
                        Level {quest.required_level}+
                      </Badge>
                    </div>
                    <CardTitle className="text-white">{quest.title}</CardTitle>
                    <CardDescription className="text-gray-400">
                      {quest.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-3 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-lg border border-yellow-500/30">
                      <div className="flex items-center gap-2 mb-2">
                        <Trophy className="w-4 h-4 text-yellow-400" />
                        <span className="text-yellow-400 text-sm font-medium">Rewards</span>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-2 text-gray-300">
                          <Coins className="w-3 h-3" />
                          {quest.reward_zeni} Zeni
                        </div>
                        <div className="flex items-center gap-2 text-gray-300">
                          <TrendingUp className="w-3 h-3" />
                          {quest.reward_exp} EXP
                        </div>
                        {quest.reward_item && (
                          <div className="text-purple-400 font-medium">
                            + {quest.reward_item}
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => acceptQuest(quest)}
                      disabled={
                        character.level < quest.required_level ||
                        createQuestMutation.isPending ||
                        activeQuests.some((q) => q.title === quest.title)
                      }
                      className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
                    >
                      {character.level < quest.required_level
                        ? `Requires Level ${quest.required_level}`
                        : "Accept Quest"}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}