import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Target, Trophy, Skull, Coins, Zap, Star, Award } from "lucide-react";
import { motion } from "framer-motion";

const bountyTiers = [
  {
    tier: 1,
    name: "Rookie Targets",
    pl: "< 300,000",
    reward: "500-1,500",
    color: "from-green-600 to-emerald-700",
    icon: Target,
  },
  {
    tier: 2,
    name: "Veteran Targets",
    pl: "300,001 - 600,000",
    reward: "1,500-3,500",
    color: "from-blue-600 to-cyan-700",
    icon: Zap,
  },
  {
    tier: 3,
    name: "Elite Targets",
    pl: "600,001 - 1,100,000",
    reward: "3,500-7,000",
    color: "from-purple-600 to-pink-700",
    icon: Star,
  },
  {
    tier: 4,
    name: "Legendary Targets",
    pl: "1,100,001 - 2,200,000",
    reward: "7,000-15,000",
    color: "from-orange-600 to-red-700",
    icon: Trophy,
  },
  {
    tier: 5,
    name: "God-Tier Targets",
    pl: "2,200,001+",
    reward: "15,000+",
    color: "from-yellow-500 to-orange-600",
    icon: Award,
  },
];

const sampleBounties = [
  { name: "Rogue Mercenary", tier: 1, pl: 250000, reward: 1200, difficulty: "Easy" },
  { name: "Space Pirate Captain", tier: 2, pl: 450000, reward: 2800, difficulty: "Medium" },
  { name: "Galactic Warlord", tier: 3, pl: 850000, reward: 5500, difficulty: "Hard" },
  { name: "Tyrant Overlord", tier: 4, pl: 1500000, reward: 12000, difficulty: "Extreme" },
];

export default function BountiesPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to hunt bounties</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-black text-white mb-2 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 bg-clip-text text-transparent">
            Bounty Hunter Guild
          </h1>
          <p className="text-gray-300 text-lg">Track down dangerous criminals for massive rewards</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {bountyTiers.map((tier, index) => (
            <motion.div
              key={tier.tier}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`bg-gradient-to-br ${tier.color} border-2 border-white/20 shadow-xl hover:scale-105 transition-transform`}>
                <CardHeader className="pb-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <tier.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white text-center text-sm font-bold">
                    Tier {tier.tier}
                  </CardTitle>
                  <p className="text-center text-white/80 text-xs font-semibold">{tier.name}</p>
                </CardHeader>
                <CardContent className="space-y-2 pt-0">
                  <div className="text-center">
                    <div className="text-white/70 text-xs">Power Level</div>
                    <div className="text-white font-bold text-sm">{tier.pl}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-white/70 text-xs">Reward</div>
                    <div className="text-yellow-200 font-black">{tier.reward}</div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Skull className="w-6 h-6 text-red-400" />
            Active Bounties
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sampleBounties.map((bounty, index) => {
              const tierInfo = bountyTiers.find(t => t.tier === bounty.tier);
              return (
                <motion.div
                  key={bounty.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  <Card className={`bg-gradient-to-br ${tierInfo.color} border-2 border-white/30 shadow-2xl`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-14 h-14 bg-black/30 rounded-lg flex items-center justify-center">
                            <Skull className="w-8 h-8 text-white" />
                          </div>
                          <div>
                            <CardTitle className="text-white text-xl">{bounty.name}</CardTitle>
                            <Badge className="bg-black/30 text-white border-0 mt-1">
                              Tier {bounty.tier} - {bounty.difficulty}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 bg-black/20 rounded-lg text-center">
                          <div className="text-white/70 text-xs mb-1">Power Level</div>
                          <div className="text-white font-bold">{bounty.pl.toLocaleString()}</div>
                        </div>
                        <div className="p-3 bg-black/20 rounded-lg text-center">
                          <div className="text-white/70 text-xs mb-1">Reward</div>
                          <div className="text-yellow-200 font-black flex items-center justify-center gap-1">
                            <Coins className="w-4 h-4" />
                            {bounty.reward.toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <Button 
                        className="w-full bg-black/30 hover:bg-black/50 text-white font-bold border-2 border-white/20"
                        disabled={character.power_level < bounty.pl}
                      >
                        {character.power_level < bounty.pl ? "Too Powerful" : "Accept Bounty"}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
        >
          <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-2 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white text-2xl font-bold">Bounty Hunter Rules</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-orange-900/20 rounded-lg border border-orange-500/30">
                  <h3 className="text-orange-400 font-bold mb-2">Requirements</h3>
                  <ul className="space-y-1 text-sm">
                    <li>• Must have Bounty Hunter side job</li>
                    <li>• Need License to Kill</li>
                    <li>• PL must match target tier</li>
                    <li>• Can only cash in at your tier or below</li>
                  </ul>
                </div>

                <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/30">
                  <h3 className="text-blue-400 font-bold mb-2">Battle Rules</h3>
                  <ul className="space-y-1 text-sm">
                    <li>• NPC gets 48 hours to post</li>
                    <li>• Battles give 1/2 stat gains</li>
                    <li>• Usually to the death</li>
                    <li>• Cannot be jumped by other players</li>
                  </ul>
                </div>
              </div>

              <div className="p-4 bg-yellow-900/20 rounded-lg border-2 border-yellow-500/50 mt-4">
                <p className="text-yellow-200 font-semibold">
                  💰 Extra Zeni Bonus: Complete bounties for massive financial rewards beyond normal battle gains!
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}