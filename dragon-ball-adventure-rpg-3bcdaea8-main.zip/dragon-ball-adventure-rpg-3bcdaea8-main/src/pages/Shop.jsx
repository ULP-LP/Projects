import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShoppingCart, Sword, Shield, Sparkles, Package, Star } from "lucide-react";
import { motion } from "framer-motion";

const itemsData = {
  usable: [
    { name: "Sensu Bean", cost: 400, description: "Heals 50% HP and restores 25% Ki in battle. Limit 3 per battle." },
    { name: "Energizer", cost: 550, description: "Allows 1 extra action in your next two posts." },
    { name: "Potion", cost: 400, description: "Restores 15% used Ki in battle." },
  ],
  equipment: [
    { name: "Weighted Clothing", cost: 1500, description: "+13 Strength, +13 Stamina training bonus. +1 DP on level up.", stat_bonuses: {strength: 13} },
    { name: "Karate Gui", cost: 750, description: "+8 Speed training bonus. Special fighting style bonuses.", stat_bonuses: {speed: 8} },
    { name: "Scouter", cost: 1200, description: "Can sense power levels. +5% Intelligence in battle.", stat_bonuses: {intelligence: 5} },
  ],
  weapons: [
    { name: "Steel Sword", cost: 500, description: "+100 Strength, +1% base. +2% damage on attacks.", stat_bonuses: {strength: 100} },
    { name: "Katana", cost: 900, description: "+100 Strength, +100 Speed. +3% damage. Fast blade.", stat_bonuses: {strength: 100, speed: 100} },
    { name: "Battle Axe", cost: 750, description: "+200 Strength. +3% damage. Heavy weapon.", stat_bonuses: {strength: 200} },
  ],
};

export default function ShopPage() {
  const [user, setUser] = useState(null);
  const [selectedTab, setSelectedTab] = useState("usable");
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const buyItem = (item) => {
    if (!character || character.zeni < item.cost) return;

    const existingItem = character.inventory.find(i => i.item_name === item.name);
    const newInventory = existingItem
      ? character.inventory.map(i => 
          i.item_name === item.name 
            ? { ...i, quantity: i.quantity + 1 }
            : i
        )
      : [...character.inventory, { item_name: item.name, quantity: 1, type: selectedTab }];

    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        zeni: character.zeni - item.cost,
        inventory: newInventory,
      },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to access the shop</p>
        </Card>
      </div>
    );
  }

  const categoryIcons = {
    usable: Sparkles,
    equipment: Shield,
    weapons: Sword,
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Item Shop</h1>
          <p className="text-gray-400">Purchase items, equipment, and weapons to strengthen your warrior</p>
          <div className="mt-4">
            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50 text-lg px-4 py-2">
              Zeni: {character.zeni.toLocaleString()}
            </Badge>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-900 border border-orange-900/30 mb-6">
            <TabsTrigger value="usable" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Sparkles className="w-4 h-4 mr-2" />
              Usable
            </TabsTrigger>
            <TabsTrigger value="equipment" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Shield className="w-4 h-4 mr-2" />
              Equipment
            </TabsTrigger>
            <TabsTrigger value="weapons" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Sword className="w-4 h-4 mr-2" />
              Weapons
            </TabsTrigger>
          </TabsList>

          {Object.keys(itemsData).map((category) => (
            <TabsContent key={category} value={category} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {itemsData[category].map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300 h-full">
                      <CardHeader>
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center mb-3">
                          <Package className="w-6 h-6 text-white" />
                        </div>
                        <CardTitle className="text-white">{item.name}</CardTitle>
                        <CardDescription className="text-gray-400">
                          {item.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {item.stat_bonuses && (
                          <div className="p-3 bg-green-900/20 rounded-lg border border-green-500/30">
                            <div className="text-green-400 text-sm font-semibold mb-1">Stat Bonuses:</div>
                            {Object.entries(item.stat_bonuses).map(([stat, value]) => (
                              <div key={stat} className="text-gray-300 text-sm">
                                +{value} {stat.charAt(0).toUpperCase() + stat.slice(1)}
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50 text-lg">
                            {item.cost} Zeni
                          </Badge>
                          <Button
                            onClick={() => buyItem(item)}
                            disabled={character.zeni < item.cost || updateCharacterMutation.isPending}
                            className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
                          >
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            Buy
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}