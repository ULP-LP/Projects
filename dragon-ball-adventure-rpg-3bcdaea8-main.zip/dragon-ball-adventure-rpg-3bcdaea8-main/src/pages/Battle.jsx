import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Swords, Heart, Sparkles, Target, Shield, Zap } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const opponents = [
  {
    name: "Weak Bandit",
    level: 1,
    hp: 80,
    ki: 50,
    difficulty: "Easy",
    reward_zeni: 100,
    reward_exp: 150,
    color: "from-green-500 to-emerald-500",
  },
  {
    name: "Mercenary",
    level: 3,
    hp: 150,
    ki: 100,
    difficulty: "Medium",
    reward_zeni: 250,
    reward_exp: 350,
    color: "from-yellow-500 to-orange-500",
  },
  {
    name: "Elite Warrior",
    level: 5,
    hp: 250,
    ki: 180,
    difficulty: "Hard",
    reward_zeni: 500,
    reward_exp: 600,
    color: "from-red-500 to-pink-500",
  },
];

function OpponentSelector({ character, onStartBattle }) {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Choose Your Opponent
          </h1>
          <p className="text-gray-400 text-lg">
            Select a worthy adversary to test your strength
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {opponents.map((opponent, index) => (
            <motion.div
              key={opponent.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-red-500/50 transition-all duration-300 h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${opponent.color} flex items-center justify-center mb-3`}>
                    <Swords className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>{opponent.name}</span>
                    <Badge className={`bg-gradient-to-r ${opponent.color} text-white border-0`}>
                      {opponent.difficulty}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="text-gray-400 text-xs mb-1">HP</div>
                      <div className="text-red-400 font-bold">{opponent.hp}</div>
                    </div>
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="text-gray-400 text-xs mb-1">Ki</div>
                      <div className="text-blue-400 font-bold">{opponent.ki}</div>
                    </div>
                  </div>

                  <Button
                    onClick={() => onStartBattle(opponent)}
                    className="w-full bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700"
                  >
                    <Swords className="w-4 h-4 mr-2" />
                    Challenge
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function BattleLog({ battle }) {
  return (
    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 h-full">
      <CardHeader>
        <CardTitle className="text-white">Battle Log</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {battle.battle_log.map((log, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className="p-3 bg-gray-800/50 rounded-lg text-gray-300 text-sm"
            >
              <span className="text-orange-400 font-mono mr-2">[{index + 1}]</span>
              {log}
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function BattleActions({ battle, character, onAction }) {
  const actions = [
    {
      name: "Physical Attack",
      icon: Swords,
      description: "Strike with physical power",
      color: "from-red-500 to-orange-500",
      action: "attack",
    },
    {
      name: "Defend",
      icon: Shield,
      description: "Reduce incoming damage by 50%",
      color: "from-blue-500 to-cyan-500",
      action: "defend",
    },
    {
      name: "Ki Blast",
      icon: Sparkles,
      description: "Powerful energy attack (20 Ki)",
      color: "from-purple-500 to-pink-500",
      action: "ki_blast",
      kiCost: 20,
    },
    {
      name: "Heal",
      icon: Heart,
      description: "Restore 20% HP (15 Ki)",
      color: "from-green-500 to-emerald-500",
      action: "heal",
      kiCost: 15,
    },
  ];

  return (
    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
      <CardHeader>
        <CardTitle className="text-white">Choose Your Action</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {actions.map((action) => (
            <motion.div
              key={action.name}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                onClick={() => onAction(action.action)}
                disabled={
                  battle.status !== "active" ||
                  (action.kiCost && battle.player_ki < action.kiCost)
                }
                className={`w-full h-auto p-4 flex flex-col items-start gap-2 bg-gradient-to-r ${action.color} hover:opacity-90 text-white border-0`}
              >
                <div className="flex items-center gap-2 w-full">
                  <action.icon className="w-5 h-5" />
                  <span className="font-semibold">{action.name}</span>
                </div>
                <span className="text-xs text-white/80">{action.description}</span>
              </Button>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function BattlePage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const { data: battles } = useQuery({
    queryKey: ['battles', user?.email],
    queryFn: async () => {
      const char = characters[0];
      if (!char) return [];
      return base44.entities.Battle.filter({ character_id: char.id, status: "active" });
    },
    initialData: [],
    enabled: !!user && characters.length > 0,
  });

  const character = characters[0];
  const activeBattle = battles[0];

  const updateBattleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Battle.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battles'] });
    },
  });

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const createBattleMutation = useMutation({
    mutationFn: (battleData) => base44.entities.Battle.create(battleData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battles'] });
    },
  });

  const startBattle = (opponent) => {
    if (!character) return;

    const battleData = {
      character_id: character.id,
      opponent_name: opponent.name,
      opponent_level: opponent.level,
      opponent_hp: opponent.hp,
      opponent_max_hp: opponent.hp,
      opponent_ki: opponent.ki,
      player_hp: character.hp,
      player_ki: character.ki,
      turn: 1,
      status: "active",
      battle_log: [`Battle started against ${opponent.name}!`],
      reward_zeni: opponent.reward_zeni,
      reward_exp: opponent.reward_exp,
    };

    createBattleMutation.mutate(battleData);
  };

  const performAction = (actionType) => {
    if (!activeBattle || !character) return;

    let damage = 0;
    let enemyDamage = 0;
    let kiCost = 0;
    let logMessage = "";
    let healAmount = 0;

    switch (actionType) {
      case "attack":
        damage = Math.floor(character.strength * 0.8 + Math.random() * 20);
        logMessage = `${character.name} attacks for ${damage} damage!`;
        break;
      case "defend":
        damage = 0;
        logMessage = `${character.name} takes a defensive stance!`;
        break;
      case "ki_blast":
        kiCost = 20;
        if (activeBattle.player_ki >= kiCost) {
          damage = Math.floor(character.intelligence * 1.2 + Math.random() * 30);
          logMessage = `${character.name} fires a Ki Blast for ${damage} damage!`;
        } else {
          logMessage = `${character.name} doesn't have enough Ki!`;
        }
        break;
      case "heal":
        kiCost = 15;
        if (activeBattle.player_ki >= kiCost) {
          healAmount = Math.floor(character.max_hp * 0.2);
          logMessage = `${character.name} heals for ${healAmount} HP!`;
        } else {
          logMessage = `${character.name} doesn't have enough Ki!`;
        }
        break;
    }

    const enemyAction = Math.random();
    if (enemyAction > 0.7) {
      enemyDamage = Math.floor(activeBattle.opponent_level * 15 + Math.random() * 20);
      logMessage += ` ${activeBattle.opponent_name} counterattacks for ${enemyDamage} damage!`;
    } else {
      enemyDamage = Math.floor(activeBattle.opponent_level * 10 + Math.random() * 15);
      logMessage += ` ${activeBattle.opponent_name} attacks for ${enemyDamage} damage!`;
    }

    if (actionType === "defend") {
      enemyDamage = Math.floor(enemyDamage * 0.5);
    }

    const newPlayerHp = Math.min(character.max_hp, Math.max(0, activeBattle.player_hp - enemyDamage + healAmount));
    const newOpponentHp = Math.max(0, activeBattle.opponent_hp - damage);
    const newPlayerKi = Math.max(0, activeBattle.player_ki - kiCost);

    let status = "active";
    let finalLog = [...activeBattle.battle_log, logMessage];

    if (newOpponentHp <= 0) {
      status = "won";
      finalLog.push(`Victory! ${character.name} defeats ${activeBattle.opponent_name}!`);
      
      updateCharacterMutation.mutate({
        id: character.id,
        data: {
          wins: character.wins + 1,
          zeni: character.zeni + activeBattle.reward_zeni,
          experience: character.experience + activeBattle.reward_exp,
          hp: character.max_hp,
          ki: character.max_ki,
        },
      });
    } else if (newPlayerHp <= 0) {
      status = "lost";
      finalLog.push(`Defeat! ${activeBattle.opponent_name} wins!`);
      
      updateCharacterMutation.mutate({
        id: character.id,
        data: {
          losses: character.losses + 1,
          hp: character.max_hp,
          ki: character.max_ki,
        },
      });
    }

    updateBattleMutation.mutate({
      id: activeBattle.id,
      data: {
        player_hp: newPlayerHp,
        player_ki: newPlayerKi,
        opponent_hp: newOpponentHp,
        turn: activeBattle.turn + 1,
        status: status,
        battle_log: finalLog,
      },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to battle</p>
        </Card>
      </div>
    );
  }

  if (!activeBattle) {
    return <OpponentSelector character={character} onStartBattle={startBattle} />;
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Battle Arena</h1>
          <Badge className="bg-red-500/20 text-red-300 border-red-500/50">
            Turn {activeBattle.turn}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-950/40 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>{character.name}</span>
                <Badge className="bg-blue-500/20 text-blue-300">You</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-300 flex items-center gap-1">
                    <Heart className="w-4 h-4 text-red-400" />
                    HP
                  </span>
                  <span className="text-red-400 font-medium">
                    {activeBattle.player_hp} / {character.max_hp}
                  </span>
                </div>
                <Progress value={(activeBattle.player_hp / character.max_hp) * 100} className="h-3 bg-gray-800" />
              </div>

              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-300 flex items-center gap-1">
                    <Sparkles className="w-4 h-4 text-blue-400" />
                    Ki
                  </span>
                  <span className="text-blue-400 font-medium">
                    {activeBattle.player_ki} / {character.max_ki}
                  </span>
                </div>
                <Progress value={(activeBattle.player_ki / character.max_ki) * 100} className="h-3 bg-gray-800" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-900/20 to-red-950/40 border-red-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>{activeBattle.opponent_name}</span>
                <Badge className="bg-red-500/20 text-red-300">Enemy</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-300 flex items-center gap-1">
                    <Heart className="w-4 h-4 text-red-400" />
                    HP
                  </span>
                  <span className="text-red-400 font-medium">
                    {activeBattle.opponent_hp} / {activeBattle.opponent_max_hp}
                  </span>
                </div>
                <Progress value={(activeBattle.opponent_hp / activeBattle.opponent_max_hp) * 100} className="h-3 bg-gray-800" />
              </div>

              <div className="p-3 bg-gray-800/50 rounded text-center">
                <div className="text-gray-400 text-sm">Level</div>
                <div className="text-white font-bold text-2xl">{activeBattle.opponent_level}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <BattleActions battle={activeBattle} character={character} onAction={performAction} />
          </div>
          <div>
            <BattleLog battle={activeBattle} />
          </div>
        </div>
      </div>
    </div>
  );
}