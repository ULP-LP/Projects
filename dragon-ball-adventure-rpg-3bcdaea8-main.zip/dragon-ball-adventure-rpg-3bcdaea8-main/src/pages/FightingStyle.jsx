import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Swords, Shield, Scale, Brain, Target, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const fightingStyles = [
  {
    name: "Aggressive",
    icon: Swords,
    mainStat: "Strength",
    description: "Fearlessly enter each battle with reckless abandon. Focus on overwhelming offense.",
    bonuses: [
      "Level 10: +5% Strength",
      "Level 20: +10% Strength, +5% Damage to physical attacks",
      "Level 40: +15% Strength, +10% Damage",
      "Level 60: +20% Strength, +15% Damage",
      "Level 80: +25% Strength, +20% Damage",
      "Level 100: +30% Strength, +25% Damage"
    ],
    color: "from-red-500 to-orange-500",
  },
  {
    name: "Defensive",
    icon: Shield,
    mainStat: "Defense",
    description: "Patient and methodical approach. Master the art of protection and counterattacks.",
    bonuses: [
      "Level 10: +5% Defense",
      "Level 20: +10% Defense, +5% Damage reduction",
      "Level 40: +15% Defense, +10% Reduction",
      "Level 60: +20% Defense, +15% Reduction",
      "Level 80: +25% Defense, +20% Reduction",
      "Level 100: +30% Defense, +25% Reduction"
    ],
    color: "from-blue-500 to-cyan-500",
  },
  {
    name: "Balanced",
    icon: Scale,
    mainStat: "All Stats",
    description: "Strike a perfect balance between offense and defense. Versatility is key.",
    bonuses: [
      "Level 10: +3% All Stats",
      "Level 20: +6% All Stats",
      "Level 40: +9% All Stats",
      "Level 60: +12% All Stats",
      "Level 80: +15% All Stats",
      "Level 100: +18% All Stats"
    ],
    color: "from-purple-500 to-pink-500",
  },
  {
    name: "Calculating",
    icon: Brain,
    mainStat: "Intelligence",
    description: "Outsmart your opponents with superior Ki control and energy attacks.",
    bonuses: [
      "Level 10: +5% Intelligence",
      "Level 20: +10% Intelligence, +5% Ki damage",
      "Level 40: +15% Intelligence, +10% Ki damage",
      "Level 60: +20% Intelligence, +15% Ki damage",
      "Level 80: +25% Intelligence, +20% Ki damage",
      "Level 100: +30% Intelligence, +25% Ki damage"
    ],
    color: "from-indigo-500 to-purple-500",
  },
  {
    name: "Tactical",
    icon: Target,
    mainStat: "Speed",
    description: "Swift movements and precise strikes. Outmaneuver and outpace your foes.",
    bonuses: [
      "Level 10: +5% Speed",
      "Level 20: +10% Speed, +5% Critical chance",
      "Level 40: +15% Speed, +10% Critical chance",
      "Level 60: +20% Speed, +15% Critical chance",
      "Level 80: +25% Speed, +20% Critical chance",
      "Level 100: +30% Speed, +25% Critical chance"
    ],
    color: "from-green-500 to-emerald-500",
  },
];

export default function FightingStylePage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const selectStyle = (styleName) => {
    if (!character) return;
    
    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        fighting_style: styleName,
        fighting_style_level: 1,
      },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to choose a fighting style</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Fighting Styles</h1>
          <p className="text-gray-400">
            Choose your combat philosophy. Available at Level 2. Styles level up through battles and training.
          </p>
          {character.fighting_style && character.fighting_style !== "None" && (
            <div className="mt-4">
              <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/50 text-lg px-4 py-2">
                Current: {character.fighting_style} - Level {character.fighting_style_level || 1}
              </Badge>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fightingStyles.map((style, index) => (
            <motion.div
              key={style.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300 h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${style.color} flex items-center justify-center mb-3`}>
                    <style.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white">{style.name}</CardTitle>
                  <CardDescription className="text-gray-400">
                    Main Stat: <span className="text-orange-400 font-semibold">{style.mainStat}</span>
                  </CardDescription>
                  <p className="text-gray-400 text-sm mt-2">{style.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300 font-semibold">Level Bonuses:</span>
                    </div>
                    <ul className="space-y-1">
                      {style.bonuses.map((bonus, i) => (
                        <li key={i} className="text-gray-400 text-sm">• {bonus}</li>
                      ))}
                    </ul>
                  </div>

                  <Button
                    onClick={() => selectStyle(style.name)}
                    disabled={
                      character.level < 2 ||
                      updateCharacterMutation.isPending ||
                      character.fighting_style === style.name
                    }
                    className={`w-full bg-gradient-to-r ${style.color} hover:opacity-90`}
                  >
                    {character.fighting_style === style.name
                      ? "Currently Selected"
                      : character.level < 2
                      ? "Requires Level 2"
                      : "Select Style"}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 mt-8">
          <CardHeader>
            <CardTitle className="text-white">How to Level Up Fighting Styles</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-400 space-y-2">
            <p>• Level 1-5: Complete 1 battle OR 4 spars</p>
            <p>• Level 6-10: Complete 1 battle OR 6 spars</p>
            <p>• Level 11-100: Complete 2 battles OR 8 spars</p>
            <p className="mt-4 text-orange-400">• You can switch styles anytime, but it resets to level 1</p>
            <p className="text-orange-400">• At level 20, you can choose a second fighting style</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}