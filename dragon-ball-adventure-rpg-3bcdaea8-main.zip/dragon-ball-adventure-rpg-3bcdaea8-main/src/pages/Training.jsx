import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp, Users, Mountain, Brain, Clock, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import { format, differenceInDays } from "date-fns";

const trainingMethods = [
  {
    name: "Self Training",
    icon: Zap,
    bonus: "+40 all stats",
    description: "Train alone to improve your basic abilities",
    color: "from-blue-500 to-cyan-500",
    stats: { strength: 40, defense: 40, speed: 40, intelligence: 40 },
  },
  {
    name: "Heavy Training",
    icon: Mountain,
    bonus: "+60 all stats",
    description: "Intense training with weighted equipment. Cannot battle during this period.",
    color: "from-red-500 to-orange-500",
    stats: { strength: 60, defense: 60, speed: 60, intelligence: 60 },
  },
  {
    name: "Meditation",
    icon: Brain,
    bonus: "+35 all stats +25 chosen stat",
    description: "Focus your mind and strengthen a specific attribute",
    color: "from-purple-500 to-pink-500",
    stats: { strength: 35, defense: 35, speed: 35, intelligence: 60 },
  },
  {
    name: "Partner Training",
    icon: Users,
    bonus: "+42 all stats",
    description: "Train with a partner to push each other's limits",
    color: "from-green-500 to-emerald-500",
    stats: { strength: 42, defense: 42, speed: 42, intelligence: 42 },
  },
];

export default function TrainingPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const startTraining = (method) => {
    if (!character) return;

    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        training_method: method.name,
        last_training: new Date().toISOString(),
      },
    });
  };

  const completeTraining = () => {
    if (!character) return;

    const method = trainingMethods.find((m) => m.name === character.training_method);
    if (!method) return;

    const newStats = {
      strength: character.strength + method.stats.strength,
      defense: character.defense + method.stats.defense,
      speed: character.speed + method.stats.speed,
      intelligence: character.intelligence + method.stats.intelligence,
      power_level: character.power_level + 500,
      experience: character.experience + 200,
      training_method: "None",
    };

    updateCharacterMutation.mutate({
      id: character.id,
      data: newStats,
    });
  };

  const canComplete = () => {
    if (!character?.last_training) return false;
    const daysSinceTraining = differenceInDays(new Date(), new Date(character.last_training));
    return daysSinceTraining >= 7;
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to begin training</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Training Grounds</h1>
          <p className="text-gray-400">
            Choose your training method to become stronger. Training takes 1 week to complete.
          </p>
        </div>

        {character.training_method !== "None" && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card className="bg-gradient-to-r from-orange-900/20 to-yellow-900/20 border-orange-500/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold text-lg mb-1">
                      Current Training: {character.training_method}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      Started: {character.last_training ? format(new Date(character.last_training), "MMM d, yyyy") : "Unknown"}
                    </p>
                  </div>
                  <Button
                    onClick={completeTraining}
                    disabled={!canComplete() || updateCharacterMutation.isPending}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    {canComplete() ? "Complete Training" : "Training in Progress"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {trainingMethods.map((method, index) => (
            <motion.div
              key={method.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300 h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center mb-3`}>
                    <method.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white">{method.name}</CardTitle>
                  <CardDescription className="text-gray-400">
                    {method.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-gray-300 text-sm font-medium">Bonuses</span>
                      </div>
                      <p className="text-green-400 font-semibold">{method.bonus}</p>
                    </div>
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-blue-400" />
                        <span className="text-gray-300 text-sm font-medium">Duration</span>
                      </div>
                      <p className="text-blue-400 font-semibold">1 Week</p>
                    </div>
                    <Button
                      onClick={() => startTraining(method)}
                      disabled={character.training_method !== "None" || updateCharacterMutation.isPending}
                      className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
                    >
                      {character.training_method === method.name ? "Currently Training" : "Start Training"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}