import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Swords, Zap, Scroll, Trophy, Sparkles, Target } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const features = [
    {
      icon: Swords,
      title: "Epic Battles",
      description: "Face powerful opponents in strategic turn-based combat",
      color: "from-red-500 to-orange-500",
    },
    {
      icon: Zap,
      title: "Train & Evolve",
      description: "Master different training methods to increase your power",
      color: "from-yellow-500 to-orange-500",
    },
    {
      icon: Scroll,
      title: "Complete Quests",
      description: "Embark on adventures and earn rewards",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Sparkles,
      title: "Transformations",
      description: "Unlock legendary super forms to boost your abilities",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Trophy,
      title: "Become Legendary",
      description: "Rise through the ranks and prove your strength",
      color: "from-green-500 to-emerald-500",
    },
    {
      icon: Target,
      title: "Strategic Combat",
      description: "Plan your moves carefully using techniques and items",
      color: "from-indigo-500 to-purple-500",
    },
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 relative"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-red-500/10 to-yellow-500/10 blur-3xl" />
          <h1 className="text-5xl md:text-7xl font-bold mb-4 relative">
            <span className="bg-gradient-to-r from-orange-400 via-red-500 to-yellow-400 bg-clip-text text-transparent">
              Warrior's Legacy
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 relative">
            A Non-Graphical Adventure Fighting RPG
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center relative">
            <Link to={createPageUrl("Character")}>
              <Button size="lg" className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white text-lg px-8 py-6">
                Start Your Journey
              </Button>
            </Link>
            <Link to={createPageUrl("Compendium")}>
              <Button size="lg" variant="outline" className="border-orange-500/50 hover:bg-orange-500/10 text-orange-300 text-lg px-8 py-6">
                Learn More
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300 h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-3`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="bg-gradient-to-r from-orange-900/20 via-red-900/20 to-yellow-900/20 border-orange-500/30">
            <CardContent className="p-8 text-center">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Begin?</h2>
              <p className="text-gray-300 mb-6 text-lg">
                Create your character and embark on an epic adventure through intense battles, rigorous training, and legendary transformations.
              </p>
              <Link to={createPageUrl("Character")}>
                <Button size="lg" className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white text-lg px-12 py-6">
                  Create Character
                </Button>
              </Link>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}