import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Swords, Sparkles, Users, Target, Scroll } from "lucide-react";

export default function CompendiumPage() {
  const races = [
    {
      name: "Saiyan",
      description: "A warrior race from Planet Vegeta with immense fighting potential.",
      advantages: [
        "Start with Zenkai ability (grow stronger after near-death)",
        "Start with Ouzaru transformation",
        "High strength base stats",
        "Access to exclusive Super Saiyan forms"
      ],
      disadvantages: ["Very low intelligence stat"],
    },
    {
      name: "Namekian",
      description: "Peaceful beings from Planet Namek with mystical powers.",
      advantages: [
        "Can regenerate lost limbs and HP",
        "Can create Dragon Balls",
        "High intelligence and ki control",
        "Access to unique fusion techniques"
      ],
      disadvantages: ["Must start on Planet Namek"],
    },
    {
      name: "Android",
      description: "Mechanical warriors with unlimited stamina.",
      advantages: [
        "No ki drain from techniques",
        "Built-in scouter",
        "Immune to battle fatigue",
        "Can be upgraded with parts"
      ],
      disadvantages: ["Cannot use healing items or senzu beans", "Cannot sense ki naturally"],
    },
    {
      name: "Human",
      description: "Versatile fighters from Earth with balanced abilities.",
      advantages: [
        "Balanced stat distribution",
        "Learn techniques faster",
        "Access to unique human techniques",
        "Can master any fighting style"
      ],
      disadvantages: ["No racial transformation initially"],
    },
    {
      name: "Hybrid",
      description: "Mixed-race warriors combining traits from multiple races.",
      advantages: [
        "Choose two racial traits",
        "Most versatile character type",
        "Unique transformation possibilities",
        "Can access multiple race-specific abilities"
      ],
      disadvantages: ["Weaker versions of racial abilities compared to pure races"],
    },
  ];

  const trainingMethods = [
    {
      name: "Self Training",
      bonus: "+40 all stats per week",
      description: "Basic solo training to improve your fundamental abilities.",
    },
    {
      name: "Heavy Training",
      bonus: "+60 all stats per week",
      description: "Intense training with weighted equipment. Cannot battle during this period.",
    },
    {
      name: "Meditation Training",
      bonus: "+35 all stats, +25 chosen stat per week",
      description: "Focus your mind to strengthen body and spirit, emphasizing one particular attribute.",
    },
    {
      name: "Partner Training",
      bonus: "+42 all stats per week",
      description: "Train with another warrior to push each other beyond normal limits.",
    },
    {
      name: "Master Training",
      bonus: "+100 all stats, +SP, +Fighting Style levels",
      description: "Train under a legendary master to learn advanced techniques and gain significant power.",
    },
  ];

  const battleTips = [
    {
      title: "Physical Attacks",
      description: "Basic attacks using your strength stat. Reliable damage with no ki cost.",
    },
    {
      title: "Defend",
      description: "Take a defensive stance to reduce incoming damage by 50% for one turn.",
    },
    {
      title: "Ki Techniques",
      description: "Powerful energy attacks that consume ki but deal massive damage based on intelligence.",
    },
    {
      title: "Transformations",
      description: "Boost all stats temporarily but drain ki each turn. Use strategically!",
    },
    {
      title: "Items",
      description: "Senzu beans and other items can turn the tide of battle. Use them wisely.",
    },
    {
      title: "Status Effects",
      description: "Some techniques can stun or weaken opponents. Learn to combo these effects.",
    },
  ];

  const questInfo = [
    {
      difficulty: "Easy",
      description: "Suitable for new warriors. Low risk, moderate rewards.",
      recommendedLevel: "1-3",
    },
    {
      difficulty: "Medium",
      description: "Challenging encounters requiring strategy. Good rewards.",
      recommendedLevel: "3-6",
    },
    {
      difficulty: "Hard",
      description: "Dangerous missions for experienced fighters. High rewards and rare items.",
      recommendedLevel: "6-10",
    },
    {
      difficulty: "Extreme",
      description: "Only the strongest warriors should attempt. Legendary rewards await.",
      recommendedLevel: "10+",
    },
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Warrior's Compendium
          </h1>
          <p className="text-gray-400">
            Everything you need to know to become the strongest fighter
          </p>
        </div>

        <Tabs defaultValue="races" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 bg-gray-900 border border-orange-900/30 mb-6">
            <TabsTrigger value="races" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Users className="w-4 h-4 mr-2" />
              Races
            </TabsTrigger>
            <TabsTrigger value="training" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Target className="w-4 h-4 mr-2" />
              Training
            </TabsTrigger>
            <TabsTrigger value="battle" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Swords className="w-4 h-4 mr-2" />
              Combat
            </TabsTrigger>
            <TabsTrigger value="quests" className="data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300">
              <Scroll className="w-4 h-4 mr-2" />
              Quests
            </TabsTrigger>
          </TabsList>

          <TabsContent value="races" className="space-y-4">
            {races.map((race) => (
              <Card key={race.name} className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-orange-400" />
                    {race.name}
                  </CardTitle>
                  <p className="text-gray-400">{race.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-green-400 font-semibold mb-2">Advantages:</h3>
                    <ul className="space-y-1">
                      {race.advantages.map((adv, i) => (
                        <li key={i} className="text-gray-300 text-sm">• {adv}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-red-400 font-semibold mb-2">Disadvantages:</h3>
                    <ul className="space-y-1">
                      {race.disadvantages.map((dis, i) => (
                        <li key={i} className="text-gray-300 text-sm">• {dis}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="training" className="space-y-4">
            {trainingMethods.map((method) => (
              <Card key={method.name} className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                <CardHeader>
                  <CardTitle className="text-white">{method.name}</CardTitle>
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/50 w-fit">
                    {method.bonus}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{method.description}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="battle" className="space-y-4">
            <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 mb-6">
              <CardHeader>
                <CardTitle className="text-white">Battle System Overview</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-400">
                <p className="mb-4">
                  Combat in Warrior's Legacy is turn-based and strategic. Each action you take has consequences,
                  and managing your HP and Ki is crucial to victory.
                </p>
                <p>
                  Your stats (Strength, Defense, Speed, Intelligence) directly affect your battle performance.
                  Train regularly to increase these stats and unlock new abilities.
                </p>
              </CardContent>
            </Card>

            {battleTips.map((tip) => (
              <Card key={tip.title} className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                <CardHeader>
                  <CardTitle className="text-white text-lg">{tip.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{tip.description}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="quests" className="space-y-4">
            <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 mb-6">
              <CardHeader>
                <CardTitle className="text-white">Quest System</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-400">
                <p>
                  Quests are missions that reward you with Zeni, experience, and sometimes rare items.
                  Complete quests to progress your character and unlock new content.
                </p>
              </CardContent>
            </Card>

            {questInfo.map((quest) => (
              <Card key={quest.difficulty} className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white">{quest.difficulty}</CardTitle>
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50">
                      Level {quest.recommendedLevel}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{quest.description}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}