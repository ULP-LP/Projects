import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, Coins, TrendingUp, Users, Shield, Zap } from "lucide-react";
import { motion } from "framer-motion";

const jobs = [
  {
    name: "Running Errands",
    level: 1,
    icon: Zap,
    reward: "+7 Speed, +300 Zeni per week",
    upgradesTo: "Route Runner",
    color: "from-yellow-500 to-orange-500",
  },
  {
    name: "Teacher",
    level: 1,
    icon: Users,
    reward: "+5 Strength, +300 Zeni per week",
    upgradesTo: "Sensei",
    color: "from-blue-500 to-cyan-500",
  },
  {
    name: "Criminal",
    level: 1,
    icon: Briefcase,
    reward: "+500 Zeni per week",
    upgradesTo: "Crime Boss",
    color: "from-red-500 to-pink-500",
  },
  {
    name: "Body Guard",
    level: 1,
    icon: Shield,
    reward: "+5 Defense, +300 Zeni per week",
    upgradesTo: "Protector",
    color: "from-green-500 to-emerald-500",
  },
  {
    name: "Route Runner",
    level: 2,
    icon: Zap,
    reward: "+12 Speed, +350 Zeni per week",
    upgradesFrom: "Running Errands",
    upgradesTo: "Delivery Manager",
    color: "from-yellow-500 to-orange-500",
  },
  {
    name: "Sensei",
    level: 2,
    icon: Users,
    reward: "+10 Strength, +350 Zeni per week",
    upgradesFrom: "Teacher",
    upgradesTo: "Master",
    color: "from-blue-500 to-cyan-500",
  },
  {
    name: "Crime Boss",
    level: 2,
    icon: Briefcase,
    reward: "+600 Zeni per week",
    upgradesFrom: "Criminal",
    upgradesTo: "Crime Lord",
    color: "from-red-500 to-pink-500",
  },
];

export default function JobsPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const selectJob = (jobName) => {
    if (!character) return;
    
    updateCharacterMutation.mutate({
      id: character.id,
      data: {
        job: jobName,
        job_level: 1,
        job_weeks: 0,
      },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to select a job</p>
        </Card>
      </div>
    );
  }

  const level1Jobs = jobs.filter(j => j.level === 1);
  const level2Jobs = jobs.filter(j => j.level === 2);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Jobs</h1>
          <p className="text-gray-400">
            Work weekly to earn extra stats and Zeni. Jobs upgrade after 3 consecutive weeks.
          </p>
          {character.job && character.job !== "None" && (
            <div className="mt-4">
              <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/50 text-lg px-4 py-2">
                Current Job: {character.job} - Week {character.job_weeks}/3 for upgrade
              </Badge>
            </div>
          )}
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">Level 1 Jobs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {level1Jobs.map((job, index) => (
              <motion.div
                key={job.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-orange-500/50 transition-all duration-300">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${job.color} flex items-center justify-center mb-3`}>
                      <job.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white">{job.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Coins className="w-4 h-4 text-yellow-400" />
                        <span className="text-gray-300 text-sm font-medium">Weekly Reward</span>
                      </div>
                      <p className="text-green-400 font-semibold">{job.reward}</p>
                    </div>

                    <div className="p-3 bg-gradient-to-r from-blue-900/20 to-purple-900/20 rounded-lg border border-blue-500/30">
                      <div className="flex items-center gap-2 mb-1">
                        <TrendingUp className="w-4 h-4 text-blue-400" />
                        <span className="text-gray-300 text-sm font-medium">Upgrades To</span>
                      </div>
                      <p className="text-blue-400 text-sm">{job.upgradesTo} (Level 2)</p>
                    </div>

                    <Button
                      onClick={() => selectJob(job.name)}
                      disabled={updateCharacterMutation.isPending || character.job === job.name}
                      className={`w-full bg-gradient-to-r ${job.color} hover:opacity-90`}
                    >
                      {character.job === job.name ? "Currently Selected" : "Select Job"}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {character.job_level >= 2 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4">Level 2 Jobs (Unlocked)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {level2Jobs.map((job, index) => (
                <motion.div
                  key={job.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                    <CardHeader>
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${job.color} flex items-center justify-center mb-3`}>
                        <job.icon className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle className="text-white">{job.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="p-3 bg-gray-800/50 rounded-lg">
                        <p className="text-green-400 font-semibold">{job.reward}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
          <CardHeader>
            <CardTitle className="text-white">Job System</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-400 space-y-2">
            <p>• Jobs provide weekly bonuses that don't interfere with other activities</p>
            <p>• Level 1 jobs upgrade to Level 2 after 3 consecutive weeks</p>
            <p>• Level 2 jobs upgrade to Level 3 after 3 more consecutive weeks</p>
            <p>• You can change your job once per week (resets progress)</p>
            <p className="mt-4 text-orange-400">• Bonuses are applied during weekly updates</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}