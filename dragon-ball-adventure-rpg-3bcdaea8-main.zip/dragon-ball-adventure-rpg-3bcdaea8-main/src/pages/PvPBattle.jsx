import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Swords, Users, Heart, Sparkles, Target, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function PvPBattlePage() {
  const [user, setUser] = useState(null);
  const [selectedOpponent, setSelectedOpponent] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const { data: allCharacters } = useQuery({
    queryKey: ['all_characters'],
    queryFn: () => base44.entities.Character.list(),
    initialData: [],
    enabled: !!user,
  });

  const { data: pvpBattles } = useQuery({
    queryKey: ['pvp_battles', user?.email],
    queryFn: async () => {
      const char = characters[0];
      if (!char) return [];
      return base44.entities.PvPBattle.filter({
        $or: [
          { challenger_id: char.id },
          { opponent_id: char.id }
        ],
        status: { $in: ["pending", "active"] }
      });
    },
    initialData: [],
    enabled: !!user && characters.length > 0,
  });

  const character = characters[0];
  const opponents = allCharacters.filter(c => c.id !== character?.id);

  const createChallengeMutation = useMutation({
    mutationFn: (battleData) => base44.entities.PvPBattle.create(battleData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pvp_battles'] });
      setSelectedOpponent(null);
    },
  });

  const updateBattleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PvPBattle.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pvp_battles'] });
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const challengePlayer = (opponent) => {
    if (!character) return;

    createChallengeMutation.mutate({
      challenger_id: character.id,
      opponent_id: opponent.id,
      status: "pending",
      challenger_hp: character.hp,
      challenger_ki: character.ki,
      opponent_hp: opponent.hp,
      opponent_ki: opponent.ki,
      current_turn: character.id,
      turn_number: 1,
      battle_log: [`${character.name} challenges ${opponent.name} to battle!`],
    });
  };

  const acceptChallenge = (battle) => {
    updateBattleMutation.mutate({
      id: battle.id,
      data: {
        status: "active",
        battle_log: [...battle.battle_log, "Challenge accepted! Battle begins!"],
      },
    });
  };

  const declineChallenge = (battle) => {
    updateBattleMutation.mutate({
      id: battle.id,
      data: { status: "declined" },
    });
  };

  if (!character) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30 p-8">
          <p className="text-white text-center">Create a character first to battle other players</p>
        </Card>
      </div>
    );
  }

  const activeBattle = pvpBattles.find(b => b.status === "active");
  const pendingChallenges = pvpBattles.filter(b => 
    b.status === "pending" && b.opponent_id === character.id
  );
  const sentChallenges = pvpBattles.filter(b => 
    b.status === "pending" && b.challenger_id === character.id
  );

  if (activeBattle) {
    const isChallenger = activeBattle.challenger_id === character.id;
    const myHp = isChallenger ? activeBattle.challenger_hp : activeBattle.opponent_hp;
    const myKi = isChallenger ? activeBattle.challenger_ki : activeBattle.opponent_ki;
    const enemyHp = isChallenger ? activeBattle.opponent_hp : activeBattle.challenger_hp;
    const enemyKi = isChallenger ? activeBattle.opponent_ki : activeBattle.challenger_ki;

    return (
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 mb-6">
            <CardContent className="p-6">
              <div className="text-center text-white">
                <h2 className="text-2xl font-bold mb-2">PvP Battle in Progress</h2>
                <p className="text-gray-400">Turn {activeBattle.turn_number}</p>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card className="bg-gradient-to-br from-blue-900/20 to-blue-950/40 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white">You</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">HP</span>
                      <span className="text-red-400 font-medium">{myHp} / {character.max_hp}</span>
                    </div>
                    <Progress value={(myHp / character.max_hp) * 100} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">Ki</span>
                      <span className="text-blue-400 font-medium">{myKi} / {character.max_ki}</span>
                    </div>
                    <Progress value={(myKi / character.max_ki) * 100} className="h-3" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-900/20 to-red-950/40 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-white">Opponent</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">HP</span>
                      <span className="text-red-400 font-medium">{enemyHp}</span>
                    </div>
                    <Progress value={enemyHp > 0 ? (enemyHp / 100) * 100 : 0} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">Ki</span>
                      <span className="text-blue-400 font-medium">{enemyKi}</span>
                    </div>
                    <Progress value={enemyKi > 0 ? (enemyKi / 100) * 100 : 0} className="h-3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
            <CardHeader>
              <CardTitle className="text-white">Battle Log</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {activeBattle.battle_log.map((log, index) => (
                  <div key={index} className="p-3 bg-gray-800/50 rounded-lg text-gray-300 text-sm">
                    <span className="text-orange-400 font-mono mr-2">[{index + 1}]</span>
                    {log}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">PvP Arena</h1>
          <p className="text-gray-400">Challenge other players to epic battles!</p>
        </div>

        {pendingChallenges.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4">Incoming Challenges</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingChallenges.map((battle) => {
                const challenger = allCharacters.find(c => c.id === battle.challenger_id);
                return (
                  <Card key={battle.id} className="bg-gradient-to-br from-orange-900/20 to-yellow-900/20 border-orange-500/50">
                    <CardHeader>
                      <CardTitle className="text-white">
                        {challenger?.name} challenges you!
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="flex gap-3">
                      <Button
                        onClick={() => acceptChallenge(battle)}
                        className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600"
                      >
                        Accept
                      </Button>
                      <Button
                        onClick={() => declineChallenge(battle)}
                        variant="outline"
                        className="flex-1"
                      >
                        Decline
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {sentChallenges.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4">Sent Challenges</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sentChallenges.map((battle) => {
                const opponent = allCharacters.find(c => c.id === battle.opponent_id);
                return (
                  <Card key={battle.id} className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        Challenge to {opponent?.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50">
                        Waiting for response...
                      </Badge>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        <div>
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Swords className="w-6 h-6 text-red-400" />
            Available Opponents
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {opponents.map((opponent, index) => (
              <motion.div
                key={opponent.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-red-500/50 transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-white">{opponent.name}</CardTitle>
                    <div className="flex gap-2 flex-wrap">
                      <Badge className="bg-orange-500/20 text-orange-300">{opponent.race}</Badge>
                      <Badge className="bg-blue-500/20 text-blue-300">Lvl {opponent.level}</Badge>
                      <Badge className="bg-purple-500/20 text-purple-300">PL: {opponent.power_level.toLocaleString()}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button
                      onClick={() => challengePlayer(opponent)}
                      disabled={createChallengeMutation.isPending}
                      className="w-full bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700"
                    >
                      <Swords className="w-4 h-4 mr-2" />
                      Challenge
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}