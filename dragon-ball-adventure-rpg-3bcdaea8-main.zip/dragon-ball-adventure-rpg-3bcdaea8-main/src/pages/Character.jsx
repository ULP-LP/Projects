import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Swords, Shield, Zap, Brain, Trophy, Coins, TrendingUp, User } from "lucide-react";
import CharacterCreation from "../components/character/CharacterCreation";
import CharacterStats from "../components/character/CharacterStats";
import CharacterInventory from "../components/character/CharacterInventory";

export default function CharacterPage() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const getUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    getUser();
  }, []);

  const { data: characters, isLoading } = useQuery({
    queryKey: ['characters', user?.email],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }),
    initialData: [],
    enabled: !!user,
  });

  const character = characters[0];

  if (isLoading || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!character) {
    return <CharacterCreation userEmail={user.email} />;
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            {character.name}
          </h1>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/50">
              {character.race}
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50">
              Level {character.level}
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/50">
              {character.transformation}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <CharacterStats character={character} />
          </div>
          <div>
            <CharacterInventory character={character} />
          </div>
        </div>
      </div>
    </div>
  );
}