import Home from './pages/Home';
import Character from './pages/Character';
import Training from './pages/Training';
import Battle from './pages/Battle';
import Quests from './pages/Quests';
import Compendium from './pages/Compendium';
import FightingStyle from './pages/FightingStyle';
import Jobs from './pages/Jobs';
import Shop from './pages/Shop';
import Techniques from './pages/Techniques';
import PvPBattle from './pages/PvPBattle';
import Alignment from './pages/Alignment';
import Bounties from './pages/Bounties';
import Layout from './Layout.jsx';


export const PAGES = {
    "Home": Home,
    "Character": Character,
    "Training": Training,
    "Battle": Battle,
    "Quests": Quests,
    "Compendium": Compendium,
    "FightingStyle": FightingStyle,
    "Jobs": Jobs,
    "Shop": Shop,
    "Techniques": Techniques,
    "PvPBattle": PvPBattle,
    "Alignment": Alignment,
    "Bounties": Bounties,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: Layout,
};