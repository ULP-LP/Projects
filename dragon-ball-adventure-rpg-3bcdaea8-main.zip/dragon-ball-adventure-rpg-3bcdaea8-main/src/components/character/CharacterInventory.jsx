import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Backpack, Sword, Shield as ShieldIcon } from "lucide-react";

export default function CharacterInventory({ character }) {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sword className="w-5 h-5 text-orange-400" />
            Equipment
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-gray-800/50 rounded-lg">
            <div className="text-gray-400 text-xs mb-1">Weapon</div>
            <div className="text-white font-medium">
              {character.equipped_weapon || "None"}
            </div>
          </div>
          <div className="p-3 bg-gray-800/50 rounded-lg">
            <div className="text-gray-400 text-xs mb-1">Armor</div>
            <div className="text-white font-medium">
              {character.equipped_armor || "None"}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Backpack className="w-5 h-5 text-blue-400" />
            Inventory
          </CardTitle>
        </CardHeader>
        <CardContent>
          {character.inventory && character.inventory.length > 0 ? (
            <div className="space-y-2">
              {character.inventory.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg"
                >
                  <div>
                    <div className="text-white font-medium">{item.item_name}</div>
                    <div className="text-gray-400 text-xs">{item.type}</div>
                  </div>
                  <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/50">
                    x{item.quantity}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-400 text-center py-4">No items in inventory</div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <ShieldIcon className="w-5 h-5 text-purple-400" />
            Techniques
          </CardTitle>
        </CardHeader>
        <CardContent>
          {character.techniques && character.techniques.length > 0 ? (
            <div className="space-y-2">
              {character.techniques.map((technique, index) => (
                <div
                  key={index}
                  className="p-3 bg-gray-800/50 rounded-lg text-white font-medium"
                >
                  {technique}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-400 text-center py-4">No techniques learned</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}