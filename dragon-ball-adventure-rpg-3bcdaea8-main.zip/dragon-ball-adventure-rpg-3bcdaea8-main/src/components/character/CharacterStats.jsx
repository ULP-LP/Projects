import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Swords, Shield, Zap, Brain, Heart, Sparkles, Trophy, Coins } from "lucide-react";

export default function CharacterStats({ character }) {
  const stats = [
    { icon: Swords, label: "Strength", value: character.strength, color: "text-red-400" },
    { icon: Shield, label: "Defense", value: character.defense, color: "text-blue-400" },
    { icon: Zap, label: "Speed", value: character.speed, color: "text-yellow-400" },
    { icon: Brain, label: "Intelligence", value: character.intelligence, color: "text-purple-400" },
  ];

  const expToNextLevel = character.level * 1000;
  const expProgress = (character.experience / expToNextLevel) * 100;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-400" />
            Vital Stats
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">HP</span>
              <span className="text-red-400 font-medium">
                {character.hp} / {character.max_hp}
              </span>
            </div>
            <Progress value={(character.hp / character.max_hp) * 100} className="h-3 bg-gray-800">
              <div className="h-full bg-gradient-to-r from-red-500 to-red-600 rounded-full" />
            </Progress>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Ki</span>
              <span className="text-blue-400 font-medium">
                {character.ki} / {character.max_ki}
              </span>
            </div>
            <Progress value={(character.ki / character.max_ki) * 100} className="h-3 bg-gray-800">
              <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full" />
            </Progress>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Experience</span>
              <span className="text-purple-400 font-medium">
                {character.experience} / {expToNextLevel}
              </span>
            </div>
            <Progress value={expProgress} className="h-3 bg-gray-800">
              <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
            </Progress>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-orange-400" />
            Combat Stats
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                <div className={`${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-gray-400 text-xs">{stat.label}</div>
                  <div className="text-white font-bold text-lg">{stat.value}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-gradient-to-r from-orange-900/20 to-yellow-900/20 rounded-lg border border-orange-500/30">
            <div className="text-orange-400 text-sm font-medium">Power Level</div>
            <div className="text-white font-bold text-2xl">{character.power_level.toLocaleString()}</div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            Battle Record
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className="text-gray-400 text-xs mb-1">Wins</div>
              <div className="text-green-400 font-bold text-xl">{character.wins}</div>
            </div>
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className="text-gray-400 text-xs mb-1">Losses</div>
              <div className="text-red-400 font-bold text-xl">{character.losses}</div>
            </div>
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className="text-gray-400 text-xs mb-1">
                <Coins className="w-3 h-3 inline mr-1" />
                Zeni
              </div>
              <div className="text-yellow-400 font-bold text-xl">{character.zeni}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}