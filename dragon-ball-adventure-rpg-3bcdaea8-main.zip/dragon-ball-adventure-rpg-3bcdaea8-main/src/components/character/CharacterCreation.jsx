import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const races = [
  {
    name: "Saiyan",
    description: "Natural warriors with incredible potential. Start with Zenkai ability and Ouzaru transformation.",
    bonuses: "High Strength, Low Intelligence",
  },
  {
    name: "Namekian",
    description: "Wise beings with regeneration powers. Can create Dragon Balls and have mystical abilities.",
    bonuses: "High Intelligence, Regeneration",
  },
  {
    name: "Android",
    description: "Mechanical warriors with unlimited stamina. Immune to ki drain but cannot use healing items.",
    bonuses: "No Ki Drain, Built-in Scouter",
  },
  {
    name: "Human",
    description: "Versatile fighters with balanced stats. Can learn techniques quickly.",
    bonuses: "Balanced Stats, Fast Learning",
  },
  {
    name: "Hybrid",
    description: "Mixed race with unique abilities. Combine traits from different races.",
    bonuses: "Customizable, Versatile",
  },
];

export default function CharacterCreation({ userEmail }) {
  const [name, setName] = useState("");
  const [race, setRace] = useState("");
  const queryClient = useQueryClient();

  const createCharacterMutation = useMutation({
    mutationFn: (characterData) => base44.entities.Character.create(characterData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const handleCreate = () => {
    if (!name || !race) return;

    const raceStats = {
      Saiyan: { strength: 70, defense: 50, speed: 60, intelligence: 30 },
      Namekian: { strength: 50, defense: 60, speed: 50, intelligence: 80 },
      Android: { strength: 60, defense: 70, speed: 60, intelligence: 50 },
      Human: { strength: 50, defense: 50, speed: 50, intelligence: 50 },
      Hybrid: { strength: 55, defense: 55, speed: 55, intelligence: 55 },
    };

    const stats = raceStats[race];

    const characterData = {
      name,
      race,
      level: 1,
      power_level: 1000,
      hp: 100,
      max_hp: 100,
      ki: 100,
      max_ki: 100,
      ...stats,
      zeni: 500,
      experience: 0,
      training_method: "None",
      transformation: "Base Form",
      available_transformations: ["Base Form"],
      wins: 0,
      losses: 0,
      inventory: [
        { item_name: "Senzu Bean", quantity: 3, type: "healing" },
        { item_name: "Training Weights", quantity: 1, type: "equipment" },
      ],
      techniques: [],
    };

    createCharacterMutation.mutate(characterData);
  };

  return (
    <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-4xl"
      >
        <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-500/30">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-3xl text-white mb-2">Create Your Warrior</CardTitle>
            <CardDescription className="text-gray-400 text-lg">
              Begin your journey to become the strongest fighter in the universe
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-white">Character Name</Label>
              <Input
                id="name"
                placeholder="Enter your warrior's name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Select Your Race</Label>
              <Select value={race} onValueChange={setRace}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Choose a race" />
                </SelectTrigger>
                <SelectContent>
                  {races.map((r) => (
                    <SelectItem key={r.name} value={r.name}>
                      {r.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {race && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-gradient-to-r from-orange-900/20 to-red-900/20 border border-orange-500/30 rounded-lg"
              >
                <h3 className="text-white font-semibold mb-2">
                  {races.find((r) => r.name === race)?.name}
                </h3>
                <p className="text-gray-300 text-sm mb-2">
                  {races.find((r) => r.name === race)?.description}
                </p>
                <p className="text-orange-400 text-sm font-medium">
                  {races.find((r) => r.name === race)?.bonuses}
                </p>
              </motion.div>
            )}

            <Button
              onClick={handleCreate}
              disabled={!name || !race || createCharacterMutation.isPending}
              className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white text-lg py-6"
            >
              {createCharacterMutation.isPending ? "Creating..." : "Create Character"}
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}