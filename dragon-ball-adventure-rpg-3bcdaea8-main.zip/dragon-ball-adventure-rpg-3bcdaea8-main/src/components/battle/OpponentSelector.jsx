import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skull, Swords, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const opponents = [
  {
    name: "Weak Bandit",
    level: 1,
    hp: 80,
    ki: 50,
    difficulty: "Easy",
    reward_zeni: 100,
    reward_exp: 150,
    color: "from-green-500 to-emerald-500",
  },
  {
    name: "Mercenary",
    level: 3,
    hp: 150,
    ki: 100,
    difficulty: "Medium",
    reward_zeni: 250,
    reward_exp: 350,
    color: "from-yellow-500 to-orange-500",
  },
  {
    name: "Elite Warrior",
    level: 5,
    hp: 250,
    ki: 180,
    difficulty: "Hard",
    reward_zeni: 500,
    reward_exp: 600,
    color: "from-red-500 to-pink-500",
  },
  {
    name: "Legendary Fighter",
    level: 10,
    hp: 500,
    ki: 400,
    difficulty: "Extreme",
    reward_zeni: 1000,
    reward_exp: 1200,
    color: "from-purple-500 to-indigo-500",
  },
];

export default function OpponentSelector({ character }) {
  const queryClient = useQueryClient();

  const createBattleMutation = useMutation({
    mutationFn: (battleData) => base44.entities.Battle.create(battleData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battles'] });
    },
  });

  const startBattle = (opponent) => {
    const battleData = {
      character_id: character.id,
      opponent_name: opponent.name,
      opponent_level: opponent.level,
      opponent_hp: opponent.hp,
      opponent_max_hp: opponent.hp,
      opponent_ki: opponent.ki,
      player_hp: character.hp,
      player_ki: character.ki,
      turn: 1,
      status: "active",
      battle_log: [`Battle started against ${opponent.name}!`],
      reward_zeni: opponent.reward_zeni,
      reward_exp: opponent.reward_exp,
    };

    createBattleMutation.mutate(battleData);
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Choose Your Opponent
          </h1>
          <p className="text-gray-400 text-lg">
            Select a worthy adversary to test your strength
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {opponents.map((opponent, index) => (
            <motion.div
              key={opponent.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 hover:border-red-500/50 transition-all duration-300 h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${opponent.color} flex items-center justify-center mb-3`}>
                    <Skull className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>{opponent.name}</span>
                    <Badge className={`bg-gradient-to-r ${opponent.color} text-white border-0`}>
                      {opponent.difficulty}
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Level {opponent.level} Fighter
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="text-gray-400 text-xs mb-1">HP</div>
                      <div className="text-red-400 font-bold">{opponent.hp}</div>
                    </div>
                    <div className="p-3 bg-gray-800/50 rounded-lg">
                      <div className="text-gray-400 text-xs mb-1">Ki</div>
                      <div className="text-blue-400 font-bold">{opponent.ki}</div>
                    </div>
                  </div>

                  <div className="p-3 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-lg border border-yellow-500/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Trophy className="w-4 h-4 text-yellow-400" />
                      <span className="text-yellow-400 text-sm font-medium">Rewards</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">{opponent.reward_zeni} Zeni</span>
                      <span className="text-gray-300">{opponent.reward_exp} EXP</span>
                    </div>
                  </div>

                  <Button
                    onClick={() => startBattle(opponent)}
                    disabled={createBattleMutation.isPending}
                    className="w-full bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700"
                  >
                    <Swords className="w-4 h-4 mr-2" />
                    Challenge
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}