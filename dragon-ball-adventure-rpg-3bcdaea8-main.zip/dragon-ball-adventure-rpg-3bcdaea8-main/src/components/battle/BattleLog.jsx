import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollText } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function BattleLog({ battle }) {
  return (
    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30 h-full">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <ScrollText className="w-5 h-5 text-orange-400" />
          Battle Log
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          <AnimatePresence>
            {battle.battle_log.map((log, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="p-3 bg-gray-800/50 rounded-lg text-gray-300 text-sm"
              >
                <span className="text-orange-400 font-mono mr-2">[{index + 1}]</span>
                {log}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
}