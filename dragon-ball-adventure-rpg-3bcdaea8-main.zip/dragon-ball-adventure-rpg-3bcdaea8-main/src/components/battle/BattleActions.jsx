import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Swords, Shield, Sparkles, Heart } from "lucide-react";
import { motion } from "framer-motion";

export default function BattleActions({ battle, character }) {
  const queryClient = useQueryClient();

  const updateBattleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Battle.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battles'] });
    },
  });

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Character.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
    },
  });

  const performAction = (actionType) => {
    let damage = 0;
    let enemyDamage = 0;
    let kiCost = 0;
    let logMessage = "";

    // Calculate player action
    switch (actionType) {
      case "attack":
        damage = Math.floor(character.strength * 0.8 + Math.random() * 20);
        logMessage = `${character.name} attacks for ${damage} damage!`;
        break;
      case "defend":
        damage = 0;
        logMessage = `${character.name} takes a defensive stance!`;
        break;
      case "ki_blast":
        kiCost = 20;
        if (battle.player_ki >= kiCost) {
          damage = Math.floor(character.intelligence * 1.2 + Math.random() * 30);
          logMessage = `${character.name} fires a Ki Blast for ${damage} damage!`;
        } else {
          logMessage = `${character.name} doesn't have enough Ki!`;
        }
        break;
      case "heal":
        kiCost = 15;
        if (battle.player_ki >= kiCost) {
          const healAmount = Math.floor(character.max_hp * 0.2);
          logMessage = `${character.name} heals for ${healAmount} HP!`;
        } else {
          logMessage = `${character.name} doesn't have enough Ki!`;
        }
        break;
    }

    // Calculate enemy action
    const enemyAction = Math.random();
    if (enemyAction > 0.7) {
      enemyDamage = Math.floor(battle.opponent_level * 15 + Math.random() * 20);
      logMessage += ` ${battle.opponent_name} counterattacks for ${enemyDamage} damage!`;
    } else {
      enemyDamage = Math.floor(battle.opponent_level * 10 + Math.random() * 15);
      logMessage += ` ${battle.opponent_name} attacks for ${enemyDamage} damage!`;
    }

    // Apply defense reduction
    if (actionType === "defend") {
      enemyDamage = Math.floor(enemyDamage * 0.5);
    }

    const newPlayerHp = Math.max(0, battle.player_hp - enemyDamage);
    const newOpponentHp = Math.max(0, battle.opponent_hp - damage);
    const newPlayerKi = Math.max(0, battle.player_ki - kiCost);

    // Check for battle end
    let status = "active";
    let finalLog = [...battle.battle_log, logMessage];

    if (newOpponentHp <= 0) {
      status = "won";
      finalLog.push(`Victory! ${character.name} defeats ${battle.opponent_name}!`);
      
      // Update character with rewards
      updateCharacterMutation.mutate({
        id: character.id,
        data: {
          wins: character.wins + 1,
          zeni: character.zeni + battle.reward_zeni,
          experience: character.experience + battle.reward_exp,
          hp: character.max_hp,
          ki: character.max_ki,
        },
      });
    } else if (newPlayerHp <= 0) {
      status = "lost";
      finalLog.push(`Defeat! ${battle.opponent_name} wins!`);
      
      // Reset character HP/Ki
      updateCharacterMutation.mutate({
        id: character.id,
        data: {
          losses: character.losses + 1,
          hp: character.max_hp,
          ki: character.max_ki,
        },
      });
    }

    // Update battle
    updateBattleMutation.mutate({
      id: battle.id,
      data: {
        player_hp: newPlayerHp,
        player_ki: newPlayerKi,
        opponent_hp: newOpponentHp,
        turn: battle.turn + 1,
        status: status,
        battle_log: finalLog,
      },
    });
  };

  const actions = [
    {
      name: "Physical Attack",
      icon: Swords,
      description: "Strike with physical power",
      color: "from-red-500 to-orange-500",
      action: "attack",
    },
    {
      name: "Defend",
      icon: Shield,
      description: "Reduce incoming damage by 50%",
      color: "from-blue-500 to-cyan-500",
      action: "defend",
    },
    {
      name: "Ki Blast",
      icon: Sparkles,
      description: "Powerful energy attack (20 Ki)",
      color: "from-purple-500 to-pink-500",
      action: "ki_blast",
      kiCost: 20,
    },
    {
      name: "Heal",
      icon: Heart,
      description: "Restore 20% HP (15 Ki)",
      color: "from-green-500 to-emerald-500",
      action: "heal",
      kiCost: 15,
    },
  ];

  return (
    <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-orange-900/30">
      <CardHeader>
        <CardTitle className="text-white">Choose Your Action</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {actions.map((action, index) => (
            <motion.div
              key={action.name}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                onClick={() => performAction(action.action)}
                disabled={
                  updateBattleMutation.isPending ||
                  battle.status !== "active" ||
                  (action.kiCost && battle.player_ki < action.kiCost)
                }
                className={`w-full h-auto p-4 flex flex-col items-start gap-2 bg-gradient-to-r ${action.color} hover:opacity-90 text-white border-0`}
              >
                <div className="flex items-center gap-2 w-full">
                  <action.icon className="w-5 h-5" />
                  <span className="font-semibold">{action.name}</span>
                </div>
                <span className="text-xs text-white/80">{action.description}</span>
              </Button>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}