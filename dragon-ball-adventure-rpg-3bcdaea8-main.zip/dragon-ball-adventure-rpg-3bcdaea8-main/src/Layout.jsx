import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Swords, User, Scroll, Trophy, Target, Zap, BookOpen, Home, 
  Briefcase, ShoppingCart, Users, Sparkles, Flame, Star, 
  Sword, Award, Map, GraduationCap, Medal
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  { title: "Home", url: createPageUrl("Home"), icon: Home, group: "Main" },
  { title: "Character", url: createPageUrl("Character"), icon: User, group: "Main" },
  
  { title: "Training", url: createPageUrl("Training"), icon: Zap, group: "Progress" },
  { title: "Fighting Styles", url: createPageUrl("FightingStyle"), icon: Target, group: "Progress" },
  { title: "Jobs", url: createPageUrl("Jobs"), icon: Briefcase, group: "Progress" },
  { title: "Super Forms", url: createPageUrl("SuperForms"), icon: Flame, group: "Progress" },
  { title: "Passives", url: createPageUrl("Passives"), icon: Star, group: "Progress" },
  
  { title: "Battle Arena", url: createPageUrl("Battle"), icon: Swords, group: "Combat" },
  { title: "PvP Battle", url: createPageUrl("PvPBattle"), icon: Users, group: "Combat" },
  { title: "Quests", url: createPageUrl("Quests"), icon: Scroll, group: "Combat" },
  { title: "Bounties", url: createPageUrl("Bounties"), icon: Award, group: "Combat" },
  
  { title: "Shop", url: createPageUrl("Shop"), icon: ShoppingCart, group: "Items" },
  { title: "Techniques", url: createPageUrl("Techniques"), icon: Sparkles, group: "Items" },
  { title: "Dragonballs", url: createPageUrl("Dragonballs"), icon: Trophy, group: "Items" },
  
  { title: "Compendium", url: createPageUrl("Compendium"), icon: BookOpen, group: "Info" },
  { title: "Alignment", url: createPageUrl("Alignment"), icon: Medal, group: "Info" },
  { title: "Universe", url: createPageUrl("Universe"), icon: Map, group: "Info" },
];

const groupedNav = navigationItems.reduce((acc, item) => {
  if (!acc[item.group]) acc[item.group] = [];
  acc[item.group].push(item);
  return acc;
}, {});

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-orange-900 via-red-900 to-yellow-900 animate-gradient">
        <style>{`
          @keyframes gradient {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
          }
          .animate-gradient {
            background-size: 200% 200%;
            animation: gradient 15s ease infinite;
          }
          .energy-glow {
            box-shadow: 0 0 20px rgba(255, 153, 0, 0.5), 0 0 40px rgba(255, 102, 0, 0.3);
            animation: pulse 2s ease-in-out infinite;
          }
          @keyframes pulse {
            0%, 100% { box-shadow: 0 0 20px rgba(255, 153, 0, 0.5), 0 0 40px rgba(255, 102, 0, 0.3); }
            50% { box-shadow: 0 0 30px rgba(255, 153, 0, 0.8), 0 0 60px rgba(255, 102, 0, 0.5); }
          }
          .ki-trail {
            position: relative;
            overflow: hidden;
          }
          .ki-trail::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: sweep 3s linear infinite;
          }
          @keyframes sweep {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
          }
        `}</style>
        
        <Sidebar className="border-r-4 border-orange-500/50 bg-gradient-to-b from-gray-950 via-orange-950/20 to-gray-950 backdrop-blur-xl">
          <SidebarHeader className="border-b-2 border-orange-500/50 p-4 ki-trail">
            <div className="flex items-center gap-3 energy-glow p-3 rounded-xl bg-gradient-to-r from-orange-600 to-red-600">
              <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-600 rounded-full flex items-center justify-center shadow-2xl">
                <Flame className="w-7 h-7 text-white animate-pulse" />
              </div>
              <div>
                <h2 className="font-black text-white text-xl tracking-wider">DBZ RPG</h2>
                <p className="text-xs text-yellow-200 font-bold">WARRIOR'S LEGACY</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-2 overflow-y-auto">
            {Object.entries(groupedNav).map(([group, items]) => (
              <SidebarGroup key={group} className="mb-2">
                <SidebarGroupLabel className="text-xs font-black text-orange-400 uppercase tracking-widest px-3 py-2 flex items-center gap-2">
                  <div className="w-1 h-4 bg-gradient-to-b from-orange-400 to-red-500 rounded-full" />
                  {group}
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {items.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`
                            hover:bg-gradient-to-r hover:from-orange-600/30 hover:to-red-600/30 
                            transition-all duration-300 rounded-lg mb-1 group relative overflow-hidden
                            ${location.pathname === item.url 
                              ? 'bg-gradient-to-r from-orange-600/50 to-red-600/50 text-white font-bold shadow-lg border-l-4 border-orange-400' 
                              : 'text-gray-300 hover:text-white'
                            }
                          `}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5 relative z-10">
                            <item.icon className={`w-5 h-5 ${location.pathname === item.url ? 'text-yellow-300' : ''}`} />
                            <span className="font-semibold">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            ))}
          </SidebarContent>

          <SidebarFooter className="border-t-2 border-orange-500/50 p-4 bg-gradient-to-r from-orange-900/30 to-red-900/30">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-gray-900/80 to-gray-800/80 border border-orange-500/30">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center shadow-lg">
                <User className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white text-sm truncate">Ultimate Warrior</p>
                <p className="text-xs text-orange-300 truncate">Power Level: ∞</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col min-h-screen">
          <header className="bg-gradient-to-r from-gray-950 via-orange-950/50 to-gray-950 border-b-4 border-orange-500/50 px-6 py-4 md:hidden backdrop-blur-xl">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-orange-600/30 p-2 rounded-lg transition-all duration-300 text-white energy-glow" />
              <div className="flex items-center gap-2">
                <Flame className="w-6 h-6 text-orange-400 animate-pulse" />
                <h1 className="text-xl font-black text-white tracking-wider">DBZ RPG</h1>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjA1IiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20 pointer-events-none" />
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}